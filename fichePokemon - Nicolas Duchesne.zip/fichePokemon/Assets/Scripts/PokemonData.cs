using UnityEngine;

public class PokemonData : MonoBehaviour
{


    //The variables shown in the unity inspector
    [SerializeField] private string pokemonName = "Pikachu";
    [SerializeField] private Types pokemonType = Types.Electric;
    [SerializeField][Min(1)] private int pokemonBaseLife = 35;
    [SerializeField][Min(1)] private int pokemonAttack = 55;
    [SerializeField][Min(1)] private int pokemonDefense = 30;
    [SerializeField][Min(0.1f)] private float pokemonWeigth = 6.2f;

    [SerializeField] private Types[] weaknessesTypes = { Types.Ground, Types.Rock };
    [SerializeField] private Types[] resistancesTypes = { Types.Flying, Types.Electric, Types.Steel };


    //The hidden variables, they will be assigned at the app's initialization  
    [HideInInspector] private int pokemonCurrentLife;
    [HideInInspector] private int pokemonStatistics;


    // Awake is called at the initialization, the two methods in it assign a value to the 2 variables pokemonCurrentLife and pokemonStatistics
    private void Awake()
    {
        InitCurrentLife();
        InitStatsPoints();
    }


    // Start is called before the first frame update, in it, we display all the variables and then our pokemon will take some damage
    private void Start()
    {
        DisplayAll();
        TakeDamage(10, Types.Ground);//We use an 10dmg attack inflicted by a Ground type pokemon, you can change this however you want
    }


    // Update is called once per frame, we  check the status of the pokemon, wether it is still alive or not
    private void Update()
    {
        CheckIfPokemonAlive();
    }


    //The two functions for intializating, called in Awake function, will assign values to variables pokemonCurrentLife and pokemonStatistics
    private void InitCurrentLife()
    {
        pokemonCurrentLife = pokemonBaseLife;
    }

    private void InitStatsPoints()
    {
        pokemonStatistics = pokemonBaseLife + pokemonAttack + pokemonDefense;
    }

    //The function DisplayAll called in the Start function, calling herself all the display functions, all the variables will be displayed
    //The display functions are just some regular display functions and are defined lower
    private void DisplayAll()
    {
        DisplayPokemonName();        //Name
        DisplayPokemonType();        //Type
        DisplayPokemonBaseLife();    //Base Life
        DisplayPokemonAttack();      //Attack
        DisplayPokemonDefense();     //Defense
        DisplayPokemonWeigth();      //Weight
        DisplayWeaknessesTypes();    //Weaknesses
        DisplayResistancesTypes();   //Resistances
        DisplayPokemonCurrentLife(); //Current Life
        DisplayPokemonStatistics();  //Statistics
    }


    //The function TakeDamage that will inflicts damage to our pokemon, will be used in the Start function
    void TakeDamage(int dmg, Types type)//we choos the amount of damage and the type of the attacking pokemon
    {
        string output = "";

        //We first determine if the dmg will be none, super effective, not very effective or neutral
        if (dmg <= 0)//none
        {
            dmg = 0;
            output = "The Pokemon takes no damage ! ";
        }
        else if (IsInArray(weaknessesTypes, type))//super effective
        {
            dmg = dmg * 2;
            output = $"It's super effective ! The pokemon looses {CheckOverDamage(dmg)} HP. ";
        }
        else if (IsInArray(resistancesTypes, type))//not very effective
        {
            dmg = dmg / 2;
            output = $"It's not very effective ! The pokemon looses {CheckOverDamage(dmg)} HP. ";
        }
        else//neutral
        {
            output = $"The Pokemon looses {CheckOverDamage(dmg)} HP.";
        }

        //Then we calculate the remaining life of our pokemon
        pokemonCurrentLife -= dmg;
        if (pokemonCurrentLife <= 0)//The pokemon is KO
        {
            pokemonCurrentLife = 0;//We dont want his HP to be negative
            output += $"Oh no, the pokemon is K.O. !";
        }
        else//The pokemon is okay
        {
            output += $"The pokemon has {pokemonCurrentLife} HPs remaining. ";
        }

        Debug.Log(output);//we display the final message with the variable output that we built through the function
    }


    //Checks if the pokemon is alive and display a message, will be used in the Update function to keep an eye on the pokemon's life
    private void CheckIfPokemonAlive()
    {
        if (pokemonCurrentLife > 0)//Pokemon is still alive
        {
            Debug.Log($"The pokemon is still alive with {pokemonCurrentLife} HPs. ");
        }
        else//Pokemon KO
        {
            Debug.Log($"The pokemon reached 0 HP and is K.O. ");
        }
    }

    //Misc Functions, differents functions that we definded to make the previous functions work easier
    //First, a function that allows to put the elements of an array in one string so we can display it easily
    private string ArrayToString(Types[] array)
    {
        string result = "";
        for (int i = 0; i < array.Length; i++)
        {
            if (i == array.Length - 1)
            {
                result += $"{array[i]}";
            }
            else
            {
                result += $"{array[i]}, ";
            }
        }
        return result;
    }

    //Second, a function that will check if a pokemon type is in an array, really useful for weaknesses and resistances in TakeDamage function
    private bool IsInArray(Types[] array, Types element)
    {
        for (int i = 0; i < array.Length; i++)
        {
            if (array[i].Equals(element))
            {
                return true;
            }
        }
        return false;
    }

    //And third, when the pokemon takes damage, we don't want to display that the pokemon lost more HP than he has, it used in the function TakeDamage
    private int CheckOverDamage(int dmg)
    {
        if (dmg > pokemonCurrentLife)
        {
            return pokemonCurrentLife;
        }
        return dmg;
    }


    //All the pokemon types, we created an enum for this
    private enum Types
    {
        Normal,
        Fighting,
        Flying,
        Poison,
        Ground,
        Rock,
        Bug,
        Ghost,
        Steel,
        Fire,
        Water,
        Grass,
        Electric,
        Psychic,
        Ice,
        Dragon,
        Fairy,
    };


    //Display functions for each variable, nothing very interesting, just some regular display functions
    private void DisplayPokemonName()
    {
        Debug.Log($"The pokemon Name is {pokemonName}");
    }

    private void DisplayPokemonType()
    {
        Debug.Log($"The pokemon Type is {pokemonType}");
    }

    private void DisplayPokemonBaseLife()
    {
        Debug.Log($"The pokemon Base Life is {pokemonBaseLife} HP");
    }

    private void DisplayPokemonAttack()
    {
        Debug.Log($"The pokemon Attack is {pokemonAttack} ATK");
    }

    private void DisplayPokemonDefense()
    {
        Debug.Log($"The pokemon Defense is {pokemonDefense} DEF");
    }

    private void DisplayPokemonWeigth()
    {
        Debug.Log($"The pokemon Weigth is {pokemonWeigth} Kg");
    }

    private void DisplayWeaknessesTypes()
    {
        Debug.Log($"The pokemon is weak against : {ArrayToString(weaknessesTypes)}");//use of ArrayToString
    }

    private void DisplayResistancesTypes()
    {
        Debug.Log($"The pokemon is resistant against : {ArrayToString(resistancesTypes)}");//use of ArrayToString
    }

    private void DisplayPokemonCurrentLife()
    {
        Debug.Log($"The pokemon current life is {pokemonCurrentLife} HP");
    }

    private void DisplayPokemonStatistics()
    {
        Debug.Log($"The pokemon total statistics is {pokemonStatistics}");
    }


    //Get Functions, we only have GetAttackDamage and we don't really use it 
    private int GetAttackDamage()
    {
        return pokemonAttack;
    }






}
